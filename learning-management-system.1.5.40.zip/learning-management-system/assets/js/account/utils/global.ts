import { MasteriyoLocalized } from '../types';

const localized: MasteriyoLocalized = (window as any)._MASTERIYO_;

export default localized;
